import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

public class Sample {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        try {
            // Step 1: Prompt user for file names
            System.out.print("Enter input file name (with path): ");
            String inputFileName = scanner.nextLine();

            System.out.print("Enter output file name: ");
            String outputFileName = scanner.nextLine();

            // Step 2: Open the input file
            File inputFile = new File("unsorted.txt");
            if (!inputFile.exists()) {
                System.out.println("File " + inputFileName + " not found.");
                return;
            }

            // Step 3: Read and process words
            Scanner input = new Scanner(inputFile);
            List<String> words = readAndProcessWords(input);
            input.close();

            // Step 4: Count and display letter frequencies
            int[] letterFrequency = countLetterFrequencies(words);
            System.out.println("Letter Frequencies:");
            printLetterFrequencies(letterFrequency);

            // Step 5: Sort words alphabetically and remove duplicates
            Set<String> uniqueWords = new TreeSet<>(words);

            // Step 6: Save unique words to the output file
            saveWordsToFile(uniqueWords, outputFileName);

            System.out.println("\nProcessing complete. Words saved to " + outputFileName);

        } catch (FileNotFoundException e) {
            System.out.println("Error: " + e.getMessage());
        } finally {
            scanner.close();
        }
    }

    /**
     * Reads words from the file, cleans them, and returns a list of valid words.
     *
     * @param input Scanner object for the file
     * @return List of processed words
     */
    public static List<String> readAndProcessWords(Scanner input) {
        List<String> words = new ArrayList<>();
        while (input.hasNext()) {
            String word = input.next();

            // Remove non-letter symbols from the beginning and end of the word
            word = word.replaceAll("^[^a-zA-Z]+|[^a-zA-Z]+$", "");

            // Validate the word (only allow letters and hyphens)
            if (!word.matches("^[a-zA-Z]+(-[a-zA-Z]+)?$")) {
                continue; // Skip invalid words
            }

            // Convert to lowercase
            word = word.toLowerCase();

            // Add cleaned word to the list
            words.add(word);
        }
        return words;
    }

    /**
     * Counts the frequency of each letter in the list of words.
     *
     * @param words List of processed words
     * @return Array containing letter frequencies ('a' to 'z')
     */
    public static int[] countLetterFrequencies(List<String> words) {
        int[] letterFrequency = new int[26];
        for (String word : words) {
            for (char c : word.toCharArray()) {
                if (Character.isLetter(c)) {
                    letterFrequency[c - 'a']++;
                }
            }
        }
        return letterFrequency;
    }

    /**
     * Prints the frequencies of each letter ('a' to 'z') to the console.
     *
     * @param letterFrequency Array of letter frequencies
     */
    public static void printLetterFrequencies(int[] letterFrequency) {
        for (char c = 'a'; c <= 'z'; c++) {
            System.out.println(c + ": " + letterFrequency[c - 'a']);
        }
    }

    /**
     * Saves a set of unique, sorted words to the specified output file.
     *
     * @param words          Set of unique words
     * @param outputFileName Name of the output file
     */
    public static void saveWordsToFile(Set<String> words, String outputFileName) {
        try (PrintWriter writer = new PrintWriter("sorted_unique.txt")) {
            for (String word : words) {
                writer.println(word);
            }
        } catch (FileNotFoundException e) {
            System.out.println("Error writing to file: " + outputFileName);
        }
    }
}

