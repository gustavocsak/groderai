import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;
/**
 * * Program Name: Lab10
 * * Author:       Crash Bandicoot
 * * Id:           102033
 * * Date:         November 19, 2024
 * * Compiler:     JDK 22.0.2
 */
public class Lab10 {
    /**
     * This program reads a text file word by word, saves it in an array of Strings, processes the words, sorts
     * the words in alphabetical order, keeps only one instance of each word and saves them in sorted order in another file.
     */
    public static void main(String[] args) throws FileNotFoundException {
        Scanner consoleInput = new Scanner(System.in);
        // Prompt the user input for input file name and output file names.
        System.out.print("Input source file name: ");
        String sourceFileName = consoleInput.next();
        System.out.print("Input output file name: ");
        String outputFileName = consoleInput.next();

        // Create file objects.
        File sourceFile = new File(sourceFileName);
        File outputFile = new File(outputFileName);

        //Check if source file exists. If not exit program.
        if (!sourceFile.exists()) {
            System.out.println("File " + sourceFileName + " not found");
            return;
        }
        // Count number of the words in the file.
        int wordCount = countWords(sourceFile);
        // Create an array and populate it with words from a file. Change all world to lower case.
        String[] allWords = getWordsFromFile(sourceFile, wordCount);
        // Print total word count and letter frequency to console.
        printWordCountAndLetterFrequency(allWords);

        //  Remove non-letter symbols in the beginning and at the end of the words, in non-letter symbol is in the middle
        //  and isn't '-' set that word to empty string.
        cleanWords(allWords);

        // Remove all empty strings from array.
        String[] validStringsArray = removeEmptyStrings(allWords);
        // Sort array in alphabetic order.
        sortArray(validStringsArray);

        // Get array with only unique words.
        String[] uniqueWords = getUniqueWords(validStringsArray);
        // Save unique words in a file.
        writeToFile(uniqueWords, outputFile);
    }

    /**
     * Counts number of the words in the file and return count.
     *
     * @param file text file to read
     *
     * @return the count of words in a file
     */
    public static int countWords(File file) throws FileNotFoundException {
        Scanner fileReader = new Scanner(file);

        int count = 0;
        while (fileReader.hasNext()) {
            fileReader.next();
            count++;
        }
        fileReader.close();

        return count;
    }

    /**
     * Creates an array of String with size equal to the number of the words in the file.
     * Populate array with words set to lowercase.
     *
     * @param file text file to read
     * @param size number of the words in the file
     *
     * @return the String array that contains all words from file in lowercase
     */
    public static String[] getWordsFromFile(File file, int size) throws FileNotFoundException {
        Scanner fileReader = new Scanner(file);
        String[] words = new String[size];

        for (int i = 0; i < words.length && fileReader.hasNext(); i++) {
            words[i] = fileReader.next().toLowerCase();
        }
        fileReader.close();

        return words;
    }

    /**
     * Print number of the words, and frequency of each letter ('a' to 'z') ignoring letter cases, on the
     * screen.
     *
     * @param words String array with words
     */
    public static void printWordCountAndLetterFrequency(String[] words) {
        // Print word count.
        System.out.println("\nWord total count: " + words.length);
        System.out.println();

        // Create an array that contains frequency of each letter.
        int[] letterFrequency = getLetterFrequency(words);
        System.out.println("Letter frequency: ");
        for (int i = 0; i < letterFrequency.length; i++) {
            System.out.printf("%c:%6d\n", (char) (i + 'a'), letterFrequency[i]);
        }
    }

    /**
     * Creates an int array to store the frequency of each letter ('a' to 'z') in all words from the input string array.
     * Ignores non-alphabet characters, assumes all strings are already in lowercase.
     *
     * @param words String array with words
     *
     * @return an int array containing frequency of each letter.
     */
    public static int[] getLetterFrequency(String[] words) {
        // An array of size total number of letters in the alphabet to store the frequency of each letter.
        int[] letterFrequency = new int['z' - 'a' + 1];
        for (int i = 0; i < words.length; i++) {
            String curWord = words[i];
            for (int j = 0; j < curWord.length(); j++) {
                char curChar = curWord.charAt(j);
                if (isALetter(curChar)) {
                    // If the character is a letter, increment the count at its corresponding position in the letterFrequency array.
                    letterFrequency[curChar - 'a'] += 1;
                }
            }
        }

        return letterFrequency;
    }

    /**
     * Clean array of strings to get valid words.
     * If words have any non-letter symbols in the beginning or at the end of the words, remove them.
     * If the word still contains any other non-letter symbol except hyphen '-', then set this word to an empty string.
     *
     * @param words String array with words
     */
    public static void cleanWords(String[] words) {
        for (int i = 0; i < words.length; i++) {
            // Remove non-letter symbols from the end and beginning.
            words[i] = trimNonLetters(words[i]);
            // If the word is invalid assign empty string to it.
            if (isInvalidWord(words[i]))
                words[i] = "";
        }
    }

    /**
     * If word have any non-letter symbols in the beginning or at the end of the words, remove them
     * from both sides of the words.
     *
     * @param word string - one word
     *
     * @return string without non-letter symbols at the beginning and end
     */
    public static String trimNonLetters(String word) {
        // Set word first character position and last position.
        int wordStart = 0;
        int wordEnd = word.length() - 1;

        // Trim front.
        while (!isALetter(word.charAt(wordStart)) && wordStart <= wordEnd) {
            // All characters arent letters.
            if (wordStart == wordEnd) return "";
            // Move start position to the next char.
            wordStart++;
        }

        // Trim end.
        while (!isALetter(word.charAt(wordEnd)) && wordEnd > wordStart) {
            // Move end position to the previous char.
            wordEnd--;
        }

        // Return word where it starts and ends with letter.
        return word.substring(wordStart, wordEnd + 1);
    }

    /**
     * Check if the word still contains any other non-letter symbol except hyphen '-', if it does the word is invalid,
     * if not it is valid.
     *
     * @param word string - one word
     *
     * @return if word is invalid return true, else return false
     */
    public static boolean isInvalidWord(String word) {
        for (int i = 0; i < word.length(); i++) {
            char curChar = word.charAt(i);
            if (!isALetter(curChar) && curChar != '-')
                // If it is non-letter and not '-' - word is invalid.
                return true;
        }

        return false;
    }

    /**
     * Removes empty values from the array, returns new array that contains only non-empty values.
     *
     * @param arr string array
     *
     * @return new array without empty strings
     */
    public static String[] removeEmptyStrings(String[] arr) {
        // An array sized to the number of non-empty strings.
        String[] onlyWords = new String[countNonEmptyStrings(arr)];
        // Used to track insert position for the array.
        int position = 0;

        for (int i = 0; i < arr.length; i++) {
            if (!arr[i].isEmpty()) {
                // If element is not empty, populate new array.
                onlyWords[position] = arr[i];
                position++;
            }
        }

        return onlyWords;
    }

    /**
     * Counts number of non-empty values in the array.
     *
     * @param arr string array
     *
     * @return count of non-empty items in the array
     */
    public static int countNonEmptyStrings(String[] arr) {
        int count = 0;
        for (int i = 0; i < arr.length; i++) {
            if (!arr[i].isEmpty())
                count++;
        }

        return count;
    }

    /**
     * Sorts string array in the alphabetic order.
     *
     * @param arr string array
     */
    public static void sortArray(String[] arr) {
        for (int i = 0; i < arr.length - 1; i++) {
            int minIndex = i;
            for (int j = i + 1; j < arr.length; j++) {
                if (arr[minIndex].compareTo(arr[j]) > 0) {
                    minIndex = j;
                }
            }

            if (minIndex != i) {
                String temp = arr[i];
                arr[i] = arr[minIndex];
                arr[minIndex] = temp;
            }
        }
    }

    /**
     * Returns array that contains unique words only. Assumes that the passed array has been sorted.
     *
     * @param arr string array
     *
     * @return string array that contains unique words
     */
    public static String[] getUniqueWords(String[] arr) {
        // An array sized to the number of unique words.
        String[] uniqueWords = new String[countUniqueWords(arr)];
        // Used to track insert position for the array.
        int position = 0;

        for (int i = 0; i < arr.length; i++) {
            if (i == 0 || !arr[i].equals(arr[i - 1])) {
                // If it is first element or the element that is not equals to the previous one, it is unique.
                uniqueWords[position] = arr[i];
                position++;
            }
        }

        return uniqueWords;
    }

    /**
     * Counts number of unique values in the array.
     *
     * @param arr string array
     *
     * @return count of the unique items in the array
     */
    public static int countUniqueWords(String[] arr) {
        int count = 1;
        for (int i = 1; i < arr.length; i++) {
            if (!arr[i].equals(arr[i - 1]))
                count++;
        }

        return count;
    }

    /**
     * Writes array of words to file.
     *
     * @param words string array of words
     * @param outputFile file to write to
     */
    public static void writeToFile(String[] words, File outputFile) throws FileNotFoundException {
        PrintWriter writer = new PrintWriter(outputFile);
        for(int i = 0; i < words.length; i++){
            writer.println(words[i]);
        }

        writer.close();
    }

    /**
     * Check if character is a letter. Assumes that the passed character is set to lowercase.
     *
     * @param character character
     *
     * @return if it is a letter returns true, if not false
     */
    public static boolean isALetter(char character) {
        return character >= 'a' && character <= 'z';
    }
}
