/**
 ** Program Name: Lab10
 ** Author: Sonic Hedgehog
 ** Id: 102031
 ** Date: Nov 18, 2024
 */
import java.util.Scanner;
import java.io.*;

public class Lab10 {
    public static void main(String[] args) throws FileNotFoundException {
        // Scanner to take input from the user for file names
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the input file name: ");
        String inFile = sc.nextLine();  // Input file name
        System.out.print("Enter the output file name: ");
        String outFile = sc.nextLine(); // Output file name
        sc.close(); // Close the scanner

        // Count the number of words in the input file
        int count = 0;
        Scanner countWords = new Scanner(new File(inFile));
        while (countWords.hasNext()) {
            count++; // Increment count for each word found
            countWords.next(); // Read next word
        }
        countWords.close(); // Close the scanner

        // Create an array to hold all words from the input file
        String[] words = new String[count];
        Scanner wordsScanner = new Scanner(new File(inFile));
        for (int i = 0; i < count; i++) {
            words[i] = wordsScanner.next().toLowerCase(); // Convert each word to lowercase and store in array
        }
        wordsScanner.close(); // Close the scanner

        // Display the number of words found in the file
        System.out.println("Number of words: " + count);

        // Count how many times each letter appears in the words
        char ch;
        for (int i = 0; i < 26; i++) {
            ch = (char) ('a' + i); // Get the letter corresponding to the index
            int letterCount = 0;
            // Iterate through each word and count occurrences of the letter
            for (String word : words) {
                for (int k = 0; k < word.length(); k++) {
                    if (word.charAt(k) == ch) {
                        letterCount++; // Increment if the letter matches
                    }
                }
            }
            // Display the count of the letter in the words
            System.out.println(ch + " appears " + letterCount + " times.");
        }

        // Filter out invalid words (e.g., non-alphabetical characters)
        String[] filteredWords = filterWords(words);
        // Sort the filtered words alphabetically
        String[] sortedWords = wordSorter(filteredWords);
        // Remove duplicate words from the sorted array
        String[] uniqueWords = removeDuplicates(sortedWords);
        // Save the unique words to the output file
        saveToFile(uniqueWords, outFile);
    }

    /**
     * If words have any non-letter symbols in the beginning or at the end of the words, they are removed.
     * If the word still contains any other non-letter symbol except hyphen '-', it is also removed.
     * @param words input array of words for filtering
     * @return new filtered array
     */
    public static String[] filterWords(String[] words) {
        String[] temp = new String[words.length]; // Temporary array to hold filtered words
        int validCount = 0; // Counter to track the number of valid words

        for (String word : words) {
            // Trim non-letter characters from the beginning of the word
            int start = 0;
            while (start < word.length() && !isLetter(word.charAt(start))) {
                start++;
            }

            // Trim non-letter characters from the end of the word
            int end = word.length() - 1;
            while (end >= start && !isLetter(word.charAt(end))) {
                end--;
            }

            // Build the cleaned word from the valid characters
            String cleanedWord = "";
            if (start <= end) {
                for (int i = start; i <= end; i++) {
                    cleanedWord += word.charAt(i); // Append valid characters
                }
            }

            // Check if the cleaned word contains only letters or hyphens
            boolean isValid = true;
            for (int i = 0; i < cleanedWord.length(); i++) {
                char c = cleanedWord.charAt(i);
                if (!isLetter(c) && c != '-') {
                    isValid = false; // If non-letter or non-hyphen character found, mark invalid
                    break;
                }
            }

            // Add the valid cleaned word to the result array
            if (isValid && !cleanedWord.isEmpty()) {
                temp[validCount++] = cleanedWord;
            }
        }

        // Create a new array to hold the final valid words
        String[] result = new String[validCount];
        for (int i = 0; i < validCount; i++) {
            result[i] = temp[i]; // Copy valid words to result array
        }

        return result;
    }

    /**
     * Verifies if something is a letter (doesn't check uppercase because of toLowerCase() earlier).
     * @param c input letter
     * @return true or false based on whether c is a letter
     */
    public static boolean isLetter(char c) {
        return (c >= 'a' && c <= 'z');
    }

    /**
     * Sorts an array of words alphabetically.
     * @param words input array of unsorted words
     * @return new sorted array of words
     */
    public static String[] wordSorter(String[] words) {
        // Create a new array with the same length as the original
        String[] sortedWords = new String[words.length];

        // Copy elements from the original array to the new one
        for (int i = 0; i < words.length; i++) {
            sortedWords[i] = words[i];  // Copy each word into the new array
        }

        int n = sortedWords.length;

        // Implement selection sort to sort the words alphabetically
        for (int i = 0; i < n - 1; i++) {
            int minIndex = i;
            for (int j = i + 1; j < n; j++) {
                if (sortedWords[j].compareTo(sortedWords[minIndex]) < 0) {
                    minIndex = j; // Find the minimum word in the remaining unsorted portion
                }
            }

            // Swap the minimum word with the current position
            String temp = sortedWords[minIndex];
            sortedWords[minIndex] = sortedWords[i];
            sortedWords[i] = temp;
        }

        return sortedWords;
    }

    /**
     * Removes any duplicate words in an array.
     * @param words input array with potential duplicates.
     * @return new array without duplicates.
     */
    public static String[] removeDuplicates(String[] words) {
        String[] temp = new String[words.length]; // Temporary array to hold unique words
        int uniqueCount = 0; // Counter to track the number of unique words

        // Check each word for duplicates
        for (String word : words) {
            boolean isDuplicate = false;
            for (int j = 0; j < uniqueCount; j++) {
                if (word.equals(temp[j])) {
                    isDuplicate = true; // Mark word as duplicate if it already exists in the temp array
                    break;
                }
            }
            // Add the word to the result array if it's not a duplicate
            if (!isDuplicate) {
                temp[uniqueCount++] = word;
            }
        }

        // Create a new array for the unique words
        String[] result = new String[uniqueCount];
        for (int i = 0; i < uniqueCount; i++) {
            result[i] = temp[i]; // Copy unique words to result array
        }

        return result;
    }

    /**
     * Writes every word in an array into a file.
     * @param words array to write
     * @param fileName name of file to write to
     * @throws FileNotFoundException if the file does not exist
     */
    public static void saveToFile(String[] words, String fileName) throws FileNotFoundException {
        PrintWriter writer = new PrintWriter(new File(fileName)); // Create PrintWriter for the output file
        for (String word : words) {
            writer.println(word); // Write each word to the file
        }
        writer.close(); // Close the writer
    }
}
