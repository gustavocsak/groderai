//Text File Processor 
//Dry Bones
//102032
//Nov 19 2024
//JDK 1.8
//Counts number of words and frequency of letters in a text file then creates a new sorted text file based on input file

import java.io.*;
import java.util.*;

public class Lab10 {

    /**
     * Main method to prompt user for file names, process words in a text file, 
     * count their frequency and save unique words to an output file in alphabetical order
     * @throws IOException If an input/output error occurs
     */
    public static void main(String[] args) throws IOException {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the intput file name: ");
        String inputFileName = scanner.nextLine();
        // Prompt for output file name
        System.out.print("Enter the output file name: ");
        String outputFileName = scanner.nextLine();
        
        // Count words in the input file
        int wordCount = countWordsInFile(inputFileName);
        System.out.println("Number of words: " + wordCount);

        // Create an array and read words
        String[] words = new String[wordCount];
        readWordsFromFile(inputFileName, words);

        // Clean and convert words to lowercase
        cleanWords(words);

        // Print letter frequency
        printLetterCount(words);

        // Sort words in alphabetical order
        sortWords(words);

        // Save unique words to the output file
        saveUniqueWords(words, outputFileName);

        scanner.close();
    }

    /**
     * Counts the number of words in the specified input file.
     * 
     * @param fileName The name of the input file
     * @return The number of words in the file
     * @throws IOException If an input/output error occurs
     */
    private static int countWordsInFile(String fileName) throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader(fileName));
        int count = 0;
        String line;
        while ((line = reader.readLine()) != null) {
            String[] words = line.split("\\s+");
            count += words.length;
        }
        reader.close();
        return count;
    }

    /**
     * Reads words from the specified input file and stores them in the provided array.
     * 
     * @param fileName The name of the input file
     * @param words An array to store the words
     * @throws IOException If an input/output error occurs
     */
    private static void readWordsFromFile(String fileName, String[] words) throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader(fileName));
        int index = 0;
        String line;
        while ((line = reader.readLine()) != null) {
            String[] lineWords = line.split("\\s+");
            for (String word : lineWords) {
                words[index++] = word;
            }
        }
        reader.close();
    }

    /**
     * Cleans words by converting them to lowercase and removing symbols 
     * from the beginning and end of each word. Words with internal symbols except for hyphens are discarded
     * @param words An array of words to be cleaned and converted to lowercase
     */
    private static void cleanWords(String[] words) {
        for (int i = 0; i < words.length; i++) {
            words[i] = words[i].toLowerCase().replaceAll("^[^a-zA-Z]+|[^a-zA-Z]+$", "");
            if (words[i].matches(".*[^a-zA-Z-].*")) {
                words[i] = ""; // Remove words with internal symbols except hyphen
            }
        }
    }

    /**
     * Prints the frequency of each letter (a-z) in the array of words
     * @param char c 
     * @param words An array of words*/
    private static void printLetterCount(String[] words) {
        int[] count = new int[26];
        for (String word : words) {
            for (char c : word.toCharArray()) {
                if (c >= 'a' && c <= 'z') {
                    count[c - 'a']++;
                }
            }
        }
        for (int i = 0; i < 26; i++) {
            System.out.println((char) ('a' + i) + ": " + count[i]);
        }
    }

    /**
     * Sorts the array of words in alphabetical order using bubble sort
     * 
     * @param words An array of words 
     */
    private static void sortWords(String[] words) {
        for (int i = 0; i < words.length - 1; i++) {
            for (int j = 0; j < words.length - i - 1; j++) {
                if (words[j].compareTo(words[j + 1]) > 0) {
                    String temp = words[j];
                    words[j] = words[j + 1];
                    words[j + 1] = temp;
                }
            }
        }
    }

    /**
     * Saves unique words from the array to the output file
     * add() doesn't add words if they are already in the set
     * equals() method checks if the String is already in the set
     * 
     * @param words An array of words 
     * @param outputFileName The name of the output file
     * @throws IOException If an input/output error occurs
     */
    private static void saveUniqueWords(String[] words, String outputFileName) throws IOException {
        Set<String> uniqueWords = new LinkedHashSet<>();
        for (String word : words) {
            if (!word.isEmpty()) {
                uniqueWords.add(word);//calls "word".equals("word") if true the word is not added
            }
        }

        BufferedWriter writer = new BufferedWriter(new FileWriter(outputFileName));
        for (String word : uniqueWords) {
            writer.write(word);
            writer.newLine();
        }
        writer.close();
    }
}
